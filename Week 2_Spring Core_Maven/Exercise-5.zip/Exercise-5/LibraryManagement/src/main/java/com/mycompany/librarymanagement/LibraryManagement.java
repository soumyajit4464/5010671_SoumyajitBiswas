/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.librarymanagement;

/**
 *
 * @author rana
 */
public class LibraryManagement {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}

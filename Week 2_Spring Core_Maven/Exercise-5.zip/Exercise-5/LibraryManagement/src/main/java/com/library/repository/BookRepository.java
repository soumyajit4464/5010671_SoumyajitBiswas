/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.library.repository;

/**
 *
 * @author rana
 */

public class BookRepository {
    // Business method
    public void performRepositoryTask() {
        System.out.println("BookRepository is performing a repository task.");
    }
}



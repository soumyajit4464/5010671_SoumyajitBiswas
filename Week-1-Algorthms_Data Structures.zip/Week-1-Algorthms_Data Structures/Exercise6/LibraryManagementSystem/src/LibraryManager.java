/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author rana
 */

import java.util.Arrays;
import java.util.Comparator;

public class LibraryManager {
    private Book[] books;
    private int count;

    public LibraryManager(int capacity) {
        books = new Book[capacity];
        count = 0;
    }

    public void addBook(Book book) {
        if (count == books.length) {
            books = Arrays.copyOf(books, books.length * 2);
        }
        books[count++] = book;
    }

    public Book linearSearchByTitle(String title) {
        for (int i = 0; i < count; i++) {
            if (books[i].getTitle().equalsIgnoreCase(title)) {
                return books[i];
            }
        }
        return null;
    }

    public Book binarySearchByTitle(String title) {
        Arrays.sort(books, 0, count, Comparator.comparing(Book::getTitle));
        int left = 0;
        int right = count - 1;

        while (left <= right) {
            int mid = left + (right - left) / 2;
            int cmp = books[mid].getTitle().compareToIgnoreCase(title);

            if (cmp == 0) {
                return books[mid];
            } else if (cmp < 0) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }

        return null;
    }

    public void traverseBooks() {
        for (int i = 0; i < count; i++) {
            System.out.println("Book ID: " + books[i].getBookId() +
                               ", Title: " + books[i].getTitle() +
                               ", Author: " + books[i].getAuthor());
        }
    }

    public static void main(String[] args) {
        LibraryManager manager = new LibraryManager(2);

        // Add books
        manager.addBook(new Book("1", "To Kill a Mockingbird", "Harper Lee"));
        manager.addBook(new Book("2", "1984", "George Orwell"));

        // Traverse books
        System.out.println("All Books:");
        manager.traverseBooks();

        // Linear search by title
        Book book = manager.linearSearchByTitle("1984");
        if (book != null) {
            System.out.println("\nLinear Search Result:");
            System.out.println("Book ID: " + book.getBookId() +
                               ", Title: " + book.getTitle() +
                               ", Author: " + book.getAuthor());
        } else {
            System.out.println("\nBook not found with Linear Search");
        }

        // Binary search by title
        book = manager.binarySearchByTitle("1984");
        if (book != null) {
            System.out.println("\nBinary Search Result:");
            System.out.println("Book ID: " + book.getBookId() +
                               ", Title: " + book.getTitle() +
                               ", Author: " + book.getAuthor());
        } else {
            System.out.println("\nBook not found with Binary Search");
        }
    }
}

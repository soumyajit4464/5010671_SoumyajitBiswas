/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author rana
 */

public class FinancialForecaster {

    // Method to predict future value using recursion
    public double predictFutureValue(double initialValue, double growthRate, int years) {
        // Base case: if years is 0, return the initial value
        if (years == 0) {
            return initialValue;
        }
        // Recursive case: calculate the future value for (years - 1) and apply growth rate
        double previousValue = predictFutureValue(initialValue, growthRate, years - 1);
        return previousValue * (1 + growthRate);
    }

    // Main method to test the recursive algorithm
    public static void main(String[] args) {
        FinancialForecaster forecaster = new FinancialForecaster();

        double initialValue = 1000.0; // Initial value in dollars
        double growthRate = 0.05;     // Annual growth rate (5%)
        int years = 10;               // Number of years to forecast

        double futureValue = forecaster.predictFutureValue(initialValue, growthRate, years);

        System.out.println("Future value after " + years + " years: $" + futureValue);
    }
}

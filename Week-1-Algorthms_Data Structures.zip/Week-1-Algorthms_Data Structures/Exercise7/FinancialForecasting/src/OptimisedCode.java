/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author rana
 */

import java.util.HashMap;
import java.util.Map;

public class OptimisedCode {
    private Map<Integer, Double> memo;

    public OptimisedCode() {
        this.memo = new HashMap<>();
    }

    // Method to predict future value using recursion with memoization
    public double predictFutureValue(double initialValue, double growthRate, int years) {
        // Base case: if years is 0, return the initial value
        if (years == 0) {
            return initialValue;
        }
        // Check if the result is already calculated
        if (memo.containsKey(years)) {
            return memo.get(years);
        }
        // Recursive case: calculate the future value for (years - 1) and apply growth rate
        double previousValue = predictFutureValue(initialValue, growthRate, years - 1);
        double futureValue = previousValue * (1 + growthRate);
        // Store the result in the memoization map
        memo.put(years, futureValue);
        return futureValue;
    }

    // Main method to test the recursive algorithm with memoization
    public static void main(String[] args) {
        FinancialForecaster forecaster = new FinancialForecaster();

        double initialValue = 1000.0; // Initial value in dollars
        double growthRate = 0.05;     // Annual growth rate (5%)
        int years = 10;               // Number of years to forecast

        double futureValue = forecaster.predictFutureValue(initialValue, growthRate, years);

        System.out.println("Future value after " + years + " years: $" + futureValue);
    }
}


/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author rana
 */

import java.util.Arrays;

public class EmployeeManager {
    private Employee[] employees;
    private int count;

    public EmployeeManager(int capacity) {
        employees = new Employee[capacity];
        count = 0;
    }

    public void addEmployee(Employee employee) {
        if (count == employees.length) {
            employees = Arrays.copyOf(employees, employees.length * 2);
        }
        employees[count++] = employee;
    }

    public Employee searchEmployee(String employeeId) {
        for (int i = 0; i < count; i++) {
            if (employees[i].getEmployeeId().equals(employeeId)) {
                return employees[i];
            }
        }
        return null;
    }

    public void traverseEmployees() {
        for (int i = 0; i < count; i++) {
            System.out.println("Employee ID: " + employees[i].getEmployeeId() + 
                               ", Name: " + employees[i].getName() +
                               ", Position: " + employees[i].getPosition() +
                               ", Salary: " + employees[i].getSalary());
        }
    }

    public void deleteEmployee(String employeeId) {
        for (int i = 0; i < count; i++) {
            if (employees[i].getEmployeeId().equals(employeeId)) {
                employees[i] = employees[count - 1];
                employees[count - 1] = null;
                count--;
                return;
            }
        }
    }

    public static void main(String[] args) {
        EmployeeManager manager = new EmployeeManager(2);

        // Add employees
        manager.addEmployee(new Employee("1", "Rana", "Manager", 90000));
        manager.addEmployee(new Employee("2", "Soumyajit", "Developer", 80000));

        // Traverse employees
        System.out.println("All Employees:");
        manager.traverseEmployees();

        // Search employee
        Employee emp = manager.searchEmployee("1");
        if (emp != null) {
            System.out.println("\nSearched Employee:");
            System.out.println("Employee ID: " + emp.getEmployeeId() +
                               ", Name: " + emp.getName() +
                               ", Position: " + emp.getPosition() +
                               ", Salary: " + emp.getSalary());
        } else {
            System.out.println("\nEmployee not found");
        }

        // Delete employee
        manager.deleteEmployee("2");
        System.out.println("\nEmployees after deletion:");
        manager.traverseEmployees();
    }
}

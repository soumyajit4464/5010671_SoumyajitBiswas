/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ecommerce;

/**
 *
 * @author rana
 */

import java.util.Arrays;

public class SearchAlgorithms {
    public static int linearSearch(Product[] products, String productName) {
        for (int i = 0; i < products.length; i++) {
            if (products[i].getProductName().equalsIgnoreCase(productName)) {
                return i;
            }
        }
        return -1;
    }

    public static int binarySearch(Product[] products, String productName) {
        int left = 0;
        int right = products.length - 1;
        
        while (left <= right) {
            int mid = left + (right - left) / 2;
            int cmp = products[mid].getProductName().compareToIgnoreCase(productName);
            
            if (cmp == 0) {
                return mid;
            } else if (cmp < 0) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        return -1;
    }

    public static void main(String[] args) {
        Product[] products = {
            new Product("1", "Laptop", "Electronics"),
            new Product("2", "Smartphone", "Electronics"),
            new Product("3", "Tablet", "Electronics"),
            new Product("4", "Headphones", "Electronics"),
            new Product("5", "Monitor", "Electronics")
        };
        
        Arrays.sort(products, (a, b) -> a.getProductName().compareToIgnoreCase(b.getProductName()));
        
        String searchName = "Tablet";
        
        int linearResult = linearSearch(products, searchName);
        int binaryResult = binarySearch(products, searchName);
        
        System.out.println("Linear Search Result: " + (linearResult == -1 ? "Not found" : products[linearResult].getProductName()));
        System.out.println("Binary Search Result: " + (binaryResult == -1 ? "Not found" : products[binaryResult].getProductName()));
    }
}


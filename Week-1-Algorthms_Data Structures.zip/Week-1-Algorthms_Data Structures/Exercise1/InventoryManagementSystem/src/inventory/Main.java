/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package inventory;

/**
 *
 * @author rana
 */

public class Main {
    public static void main(String[] args) {
        InventoryManager manager = new InventoryManager();
        
        // Add products
        Product p1 = new Product("1", "Product1", 10, 99.99);
        Product p2 = new Product("2", "Product2", 5, 149.99);
        
        manager.addProduct(p1);
        manager.addProduct(p2);
        
        // Update product
        p1.setPrice(89.99);
        manager.updateProduct(p1);
        
        // Delete product
        manager.deleteProduct("2");
        
        // Retrieve and display product
        Product product = manager.getProduct("1");
        if (product != null) {
            System.out.println("Product ID: " + product.getProductId());
            System.out.println("Product Name: " + product.getProductName());
            System.out.println("Quantity: " + product.getQuantity());
            System.out.println("Price: " + product.getPrice());
        }
    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author rana
 */
public class SortingAlgorithms {

    /**
     * @param args the command line arguments
     */
    
    public static void bubbleSort(Order[] orders) {
        int n = orders.length;
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                if (orders[j].getTotalPrice() > orders[j + 1].getTotalPrice()) {
                    // Swap orders[j] and orders[j+1]
                    Order temp = orders[j];
                    orders[j] = orders[j + 1];
                    orders[j + 1] = temp;
                }
            }
        }
    }

    public static void quickSort(Order[] orders, int low, int high) {
        if (low < high) {
            int pi = partition(orders, low, high);
            quickSort(orders, low, pi - 1);
            quickSort(orders, pi + 1, high);
        }
    }

    private static int partition(Order[] orders, int low, int high) {
        Order pivot = orders[high];
        int i = (low - 1);
        for (int j = low; j < high; j++) {
            if (orders[j].getTotalPrice() <= pivot.getTotalPrice()) {
                i++;
                // Swap orders[i] and orders[j]
                Order temp = orders[i];
                orders[i] = orders[j];
                orders[j] = temp;
            }
        }
        // Swap orders[i+1] and orders[high] (or pivot)
        Order temp = orders[i + 1];
        orders[i + 1] = orders[high];
        orders[high] = temp;
        return i + 1;
    }

    public static void main(String[] args) {
        Order[] orders = {
            new Order("1", "Rana", 250.00),
            new Order("2", "Biswas", 150.00),
            new Order("3", "Soumyajit", 450.00),
            new Order("4", "Roumyajit", 350.00),
            new Order("5", "Parna", 50.00)
        };

        System.out.println("Unsorted Orders:");
        for (Order order : orders) {
            System.out.println(order.getCustomerName() + ": $" + order.getTotalPrice());
        }

        bubbleSort(orders);
        System.out.println("\nOrders Sorted by Bubble Sort:");
        for (Order order : orders) {
            System.out.println(order.getCustomerName() + ": $" + order.getTotalPrice());
        }

        // Shuffle and sort again with Quick Sort
        orders = new Order[]{
            new Order("1", "Rana", 250.00),
            new Order("2", "Biswas", 150.00),
            new Order("3", "Soumyajit", 450.00),
            new Order("4", "Roumyajit", 350.00),
            new Order("5", "Parna", 50.00)
        };

        quickSort(orders, 0, orders.length - 1);
        System.out.println("\nOrders Sorted by Quick Sort:");
        for (Order order : orders) {
            System.out.println(order.getCustomerName() + ": $" + order.getTotalPrice());
        }
    }
    
}

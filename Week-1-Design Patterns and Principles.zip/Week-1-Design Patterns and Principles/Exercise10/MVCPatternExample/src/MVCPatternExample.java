/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author rana
 */
public class MVCPatternExample {
    public static void main(String[] args) {
        // Create the model
        Student model = new Student();
        model.setName("Soumyajit Hero");
        model.setId("1234");
        model.setGrade("A");

        // Create the view
        StudentView view = new StudentView();

        // Create the controller
        StudentController controller = new StudentController(model, view);

        // Update the view
        controller.updateView();

        // Update the model data
        controller.setStudentName("Biswas Hero");
        controller.setStudentGrade("B");

        // Update the view again
        controller.updateView();
    }
}


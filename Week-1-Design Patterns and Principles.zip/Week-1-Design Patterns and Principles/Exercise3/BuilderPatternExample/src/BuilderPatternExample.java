/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author rana
 */
public class BuilderPatternExample {
    public static void main(String[] args) {
        Computer gamingComputer = new Computer.Builder()
                .setCPU("Intel Core i9")
                .setRAM("32GB")
                .setStorage("1TB SSD")
                .setGraphicsCard("NVIDIA RTX 3080")
                .setPowerSupply("750W")
                .setCoolingSystem("Liquid Cooling")
                .setCaseType("Mid Tower")
                .setOperatingSystem("Windows 11")
                .build();

        Computer officeComputer = new Computer.Builder()
                .setCPU("Intel Core i5")
                .setRAM("16GB")
                .setStorage("512GB SSD")
                .setGraphicsCard("Integrated Graphics")
                .setPowerSupply("500W")
                .setCoolingSystem("Air Cooling")
                .setCaseType("Mini Tower")
                .setOperatingSystem("Windows 10")
                .build();

        System.out.println("Gaming Computer Configuration:");
        System.out.println("CPU: " + gamingComputer.getCPU());
        System.out.println("RAM: " + gamingComputer.getRAM());
        System.out.println("Storage: " + gamingComputer.getStorage());
        System.out.println("Graphics Card: " + gamingComputer.getGraphicsCard());
        System.out.println("Power Supply: " + gamingComputer.getPowerSupply());
        System.out.println("Cooling System: " + gamingComputer.getCoolingSystem());
        System.out.println("Case Type: " + gamingComputer.getCaseType());
        System.out.println("Operating System: " + gamingComputer.getOperatingSystem());

        System.out.println("\nOffice Computer Configuration:");
        System.out.println("CPU: " + officeComputer.getCPU());
        System.out.println("RAM: " + officeComputer.getRAM());
        System.out.println("Storage: " + officeComputer.getStorage());
        System.out.println("Graphics Card: " + officeComputer.getGraphicsCard());
        System.out.println("Power Supply: " + officeComputer.getPowerSupply());
        System.out.println("Cooling System: " + officeComputer.getCoolingSystem());
        System.out.println("Case Type: " + officeComputer.getCaseType());
        System.out.println("Operating System: " + officeComputer.getOperatingSystem());
    }
}


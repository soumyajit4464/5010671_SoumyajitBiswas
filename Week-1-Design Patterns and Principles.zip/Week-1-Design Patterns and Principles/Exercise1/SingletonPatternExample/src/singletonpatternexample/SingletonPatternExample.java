/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package singletonpatternexample;

/**
 *
 * @author rana
 */
package singletonpatternexample;

public class SingletonPatternExample {
    public static void main(String[] args) {
        // Get the instance of Logger
        Logger logger1 = Logger.getInstance();
        logger1.log("This is the first log message");

        // Get another instance of Logger
        Logger logger2 = Logger.getInstance();
        logger2.log("This is the second log message");

        // Verify that both instances are the same
        if (logger1 == logger2) {
            System.out.println("Both logger instances are the same");
        } else {
            System.out.println("Logger instances are different");
        }
    }
}

